//
//  ViewController.swift
//  CalcApp
//
//  Created by Татьяна Биркле on 27.01.2024.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    @IBOutlet weak var resultLabel: UILabel!
    
    var number1: Double = 0
    var number2: Double = 0
    var selectedOperation: Operation?
    var text: String = ""
    
    enum Operation {
        case add, subtract, multyply, divide, equals
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultLabel.text = "0"
    }
    
    func IsPointIntoString () -> Bool {
        let point  = "."
        let text = resultLabel.text
        if text!.contains(point) {
            return true
        }else{
            return false
        }
    }
    
    @IBAction func PressPoint(sender: UIButton) {
        let tempNum: String = "."
        if IsPointIntoString() == true {
            
        }else{
            let text: String = resultLabel.text!
            resultLabel.text = "\(text)\(tempNum)"
        }
    }
    
    @IBAction func pressNum(_ sender: UIButton) {
        let tempNum = sender.tag
        if resultLabel.text == "0" {
            resultLabel.text = "\(tempNum)"
        }else if let text = resultLabel.text {
            resultLabel.text = "\(text)\(tempNum)"
        }
    }
    
    @IBAction func ClearAll(_ sender: UIButton) {
        resultLabel.text = "0"
        number1 = 0
        number2 = 0
        selectedOperation = nil
    }
    
    @IBAction func DeleteLastNumber(_ sender: UIButton) {
        if resultLabel.text!.count >= 2 {
            resultLabel.text?.removeLast()
        }else{
            resultLabel.text = "0"
        }
    }
    
    func IsMinusIntoString () -> Bool {
        let minus  = "-"
        let text = resultLabel.text
        if text!.contains(minus) {
            return true
        }else{
            return false
        }
    }
    
    @IBAction func PositiveOrNegative(_ sender: UIButton) {
        if resultLabel.text != "0" {
            let tempNum: String = "-"
            if IsMinusIntoString() == true {
                resultLabel.text?.removeFirst()
            }else{
                let text: String = resultLabel.text!
                resultLabel.text = "\(tempNum)\(text)"
            }
        }else{
            resultLabel.text = "0"
        }
    }
    
    @IBAction func SelectOperation(_ sender: UIButton) {
        let select  = sender.tag
        let text: String = resultLabel.text!
        let number1 = Double(text)
        
        
        if select == 1 {
            selectedOperation = .add
        }
        if select == 2 {
            selectedOperation = .subtract
        }
        if select == 3 {
            selectedOperation = .multyply
        }
        if select == 4 {
            selectedOperation = .divide
        }
        
        if let operation = selectedOperation {
            var number2 = 0
            if let text: String = resultLabel.text {
                let number2 = Double(text)
                
                
                switch operation {
                case .add:
                    var number1 = number1! + number2!
                    var number2 = 0
                    selectedOperation = nil
                    resultLabel.text = "\(number1)"
                    break
                    
                case .subtract:
                    
                    var number1 = (number1!) - (number2!)
                    var number2 = 0
                    selectedOperation = nil
                    resultLabel.text = "\(number1)"
                    break
                    
                case .multyply:
                    
                    var number1 = (number1!) * (number2!)
                    var number2 = 0
                    selectedOperation = nil
                    resultLabel.text = "\(number1)"
                    break
                    
                case .divide:
                    
                    var number1 = (number1!) / (number2!)
                    var number2 = 0
                    selectedOperation = nil
                    resultLabel.text = "\(number1)"
                    break
                    
                case .equals:
                    var result = number1
                    var number2 = 0
                    selectedOperation = nil
                    resultLabel.text = "\(result)"
                    break
                }
            }
        }
    }
}
        
        
        
    
    
    
    




